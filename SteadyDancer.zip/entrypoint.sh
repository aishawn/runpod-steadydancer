#!/bin/bash

# Exit immediately if a command exits with a non-zero status.
set -e

# Start ComfyUI in the background
echo "Starting ComfyUI in the background..."
python /ComfyUI/main.py --listen --use-sage-attention &
COMFYUI_PID=$!

# Wait for ComfyUI to be ready
echo "Waiting for ComfyUI to be ready..."
max_wait=120  # 최대 2분 대기
wait_count=0
while [ $wait_count -lt $max_wait ]; do
    if curl -s http://127.0.0.1:8188/ > /dev/null 2>&1; then
        echo "ComfyUI is ready!"
        break
    fi
    echo "Waiting for ComfyUI... ($wait_count/$max_wait)"
    sleep 2
    wait_count=$((wait_count + 2))
done

if [ $wait_count -ge $max_wait ]; then
    echo "Error: ComfyUI failed to start within $max_wait seconds"
    exit 1
fi

# Start the handler in the foreground if it exists
# 이 스크립트가 컨테이너의 메인 프로세스가 됩니다.
if [ -f "handler.py" ]; then
    echo "Starting the handler..."
    exec python handler.py
else
    echo "No handler.py found. Keeping ComfyUI running..."
    echo "ComfyUI is available at http://0.0.0.0:8188"
    echo "You can access the ComfyUI web interface or use the API."
    # Keep the container running by waiting for ComfyUI process
    wait $COMFYUI_PID
fi